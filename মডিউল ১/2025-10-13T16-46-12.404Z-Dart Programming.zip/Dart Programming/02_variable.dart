void main() {
  String name = 'Momshad';

  print('Hello, $name!');
}
